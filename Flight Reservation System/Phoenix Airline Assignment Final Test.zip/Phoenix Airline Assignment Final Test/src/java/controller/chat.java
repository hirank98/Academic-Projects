
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Chat;


@WebServlet(name = "chat", urlPatterns = {"/chat"})
public class chat extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
    }


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);

        PrintWriter out = response.getWriter();
        
        String cchat = request.getParameter("cchat");
        String mail = request.getParameter("email");
        String task = request.getParameter("task");
        String date = request.getParameter("date");

        String value=null;
        String name=null;
        
         Cookie ck[]=request.getCookies();  
        for(int i=0;i<ck.length;i++){  
        name= ck[i].getName();
        value = ck[i].getValue();
        }
        if(name.equals("user") || name.equals("staffmail"))
        {
            request.setAttribute("filteruser", value);
        }
          String filter = (String)request.getAttribute("filteruser");
        
        Chat ch = new Chat();
        ch.setCchat(cchat);
        ch.setEmail(mail);
        ch.setPerson(filter);
        ch.setTask(task);
        ch.setDate(date);
       
        if(ch.chat())
        {
            ch.track();
            out.println("<script type=\"text/javascript\">");
            out.println("alert('Message Sent!!!...')");
            out.println("location='error.jsp';");
            out.println("</script>");
        }
        else
        {
            out.println("<script type=\"text/javascript\">");
            out.println("alert('You have already sent a message.. Please Wait For The Reply!!')");
            out.println("location='error.jsp';");
            out.println("</script>");
        }
    }

 
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
