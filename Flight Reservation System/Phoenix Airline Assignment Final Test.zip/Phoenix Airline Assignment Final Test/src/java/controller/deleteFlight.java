
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Flight;


@WebServlet(name = "deleteFlight", urlPatterns = {"/deleteFlight"})
public class deleteFlight extends HttpServlet {


    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
       
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

 
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        PrintWriter out = response.getWriter();
        String id = request.getParameter("id");
        String task = request.getParameter("task");
        String date = request.getParameter("date");
        
        String value=null;
        String name=null;
        
         Cookie ck[]=request.getCookies();  
        for(int i=0;i<ck.length;i++){  
        name= ck[i].getName();
        value = ck[i].getValue();
        }
        if(name.equals("user") || name.equals("staffmail"))
        {
            request.setAttribute("filteruser", value);
        }
          String filter = (String)request.getAttribute("filteruser");
        
        Flight f1 = new Flight();
        f1.setId(id);
        f1.setPerson(filter);
        f1.setTask(task);
        f1.setDate(date);
        
        if(f1.staffTrack() && f1.deleteFlight())
        {
            out.println("<script type=\"text/javascript\">");
            out.println("alert(' Flight Deleted..')");
            out.println("location='flightsedit.jsp';");
            out.println("</script>");      
        }
        else
        {
            out.println("<script type=\"text/javascript\">");
            out.println("alert(' Flight Delete Failed..')");
            out.println("location='flightsedit.jsp';");
            out.println("</script>");    
        }
        
    }


    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
