
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Client;


@WebServlet(name = "clientservlet", urlPatterns = {"/clientservlet"})
public class clientservlet extends HttpServlet {


    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
       
    }


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        PrintWriter out = response.getWriter();
        String title = request.getParameter("ddltitle");
        String fname = request.getParameter("fname");
        String sname = request.getParameter("sname");
        String username = request.getParameter("username");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String gender = request.getParameter("gender");
        String telephone = request.getParameter("telephone");
        
        
       
       
       Client c1 = new Client();
       c1.setTitle(title);
       c1.setFname(fname);
       c1.setSname(sname);
       c1.setUsername(username);
       c1.setEmail(email);
       c1.setPassword(password);
       c1.setGender(gender);
       c1.setTelephone(telephone);
       
       if(!c1.loginUsername())
       {
           if(!c1.loginEmail())
           {
              if(!c1.blockedEmail())
              {
                  if(!c1.blockedUsername())
                  {
                      if(!c1.loginPassword())
                      {
                       if(!c1.blockedPassword())
                       {  
               if(c1.signup())
               {
                   RequestDispatcher rd = request.getRequestDispatcher("clientlogin.jsp");
                   rd.include(request, response);
               }
               else
               {
                    out.println("<script type=\"text/javascript\">");
                    out.println("alert('Signup Failed..')");
                    out.println("location='clientsignup.jsp';");
                    out.println("</script>");
               }
                 }
                 else
                       {
                    out.println("<script type=\"text/javascript\">");
                    out.println("alert('Please Enter a Strong Password..')");
                    out.println("location='clientsignup.jsp';");
                    out.println("</script>");   
                       }
                      }
                           
                else
                      {
                    out.println("<script type=\"text/javascript\">");
                    out.println("alert('Please Enter a Strong Password..')");
                    out.println("location='clientsignup.jsp';");
                    out.println("</script>"); 
                      }
              }
              else
              {
                    out.println("<script type=\"text/javascript\">");
                    out.println("alert('Username Already Taken..')");
                    out.println("location='clientsignup.jsp';");
                    out.println("</script>");
              }
              }
           else
           {
                    out.println("<script type=\"text/javascript\">");
                    out.println("alert('E-Mail Already Taken..')");
                    out.println("location='clientsignup.jsp';");
                    out.println("</script>");
           }
           }
           
           else
           {
                    out.println("<script type=\"text/javascript\">");
                    out.println("alert('E-Mail Already Taken..')");
                    out.println("location='clientsignup.jsp';");
                    out.println("</script>");
           }
                    
           
       }
       else
       {
                    out.println("<script type=\"text/javascript\">");
                    out.println("alert('Username Already Taken..')");
                    out.println("location='clientsignup.jsp';");
                    out.println("</script>");
       }
       
       
       
       
       
    }


    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
