
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Reserve;


@WebServlet(name = "editreservationdetails", urlPatterns = {"/editreservationdetails"})
public class editreservationdetails extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
     
    }


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        PrintWriter out = response.getWriter();
        
        String email = request.getParameter("email");
        String task = request.getParameter("task");
        String date = request.getParameter("date");
 
        String value=null;
        String name=null;
        
         Cookie ck[]=request.getCookies();  
        for(int i=0;i<ck.length;i++){  
        name= ck[i].getName();
        value = ck[i].getValue();
        }
        if(name.equals("user") || name.equals("staffmail"))
        {
            request.setAttribute("filteruser", value);
        }
          String filter = (String)request.getAttribute("filteruser");
          
        Reserve r1 = new Reserve();
        r1.setEmail(email);
        r1.setPerson(filter);
        r1.setTask(task);
        r1.setDate(date);
        
     
            if(r1.reservation().isEmpty())
            {
            out.println("<script type=\"text/javascript\">");
            out.println("alert('No Reservation Found..')");
            out.println("location='error.jsp';");
            out.println("</script>");   
            }
            else
            {
            r1.track();
            List reservation = r1.reservation();
            request.setAttribute("reservation", reservation);
            RequestDispatcher rd = request.getRequestDispatcher("reserveupdate.jsp");
            rd.forward(request, response);
            }
       
        

        
        
        
        
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
