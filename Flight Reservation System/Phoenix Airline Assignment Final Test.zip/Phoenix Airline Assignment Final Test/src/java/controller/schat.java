
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Chat;


@WebServlet(name = "schat", urlPatterns = {"/schat"})
public class schat extends HttpServlet {


    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
       
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        PrintWriter out  = response.getWriter();
        String id = request.getParameter("id");
        String email = request.getParameter("email");
        String schat = request.getParameter("schat");
        String task = request.getParameter("task");
        String date = request.getParameter("date");

        String value=null;
        String name=null;
        
         Cookie ck[]=request.getCookies();  
        for(int i=0;i<ck.length;i++){  
        name= ck[i].getName();
        value = ck[i].getValue();
        }
        if(name.equals("staffmail"))
        {
            request.setAttribute("filteruser", value);
        }
          String filter = (String)request.getAttribute("filteruser");

        
     Chat ch = new Chat();
       ch.setEmail(email);
       ch.setSchat(schat);
       ch.setPerson(filter);
       ch.setTask(task);
       ch.setDate(date);
       
       if(ch.schat())
       {
            ch.staffTrack();
            ch.backChat();
            out.println("<script type=\"text/javascript\">");
            out.println("alert('Replied!!!...')");
            out.println("location='staffchatredirect.jsp';");
            out.println("</script>");
       }
       else
       {
           
            out.println("<script type=\"text/javascript\">");
            out.println("alert('Already Replied!!!...')");
            out.println("location='staffchatredirect.jsp';");
            out.println("</script>");
       }

           
           
    }

  
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
