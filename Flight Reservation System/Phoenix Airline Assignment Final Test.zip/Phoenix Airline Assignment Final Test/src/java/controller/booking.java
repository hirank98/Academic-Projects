
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Reserve;


@WebServlet(name = "booking", urlPatterns = {"/booking"})
public class booking extends HttpServlet {


    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
    }


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        
        
       
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        PrintWriter out = response.getWriter();
        String title = request.getParameter("title");
        String fname = request.getParameter("fname");
        String lname = request.getParameter("lname");
        String email = request.getParameter("email");
        String telephone = request.getParameter("telephone");
        String id = request.getParameter("id");
        String type = request.getParameter("type");
        String departcountry = request.getParameter("departcountry");
        String depcity = request.getParameter("depcity");
        String descountry = request.getParameter("descountry");
        String descity = request.getParameter("descity");
        String airline = request.getParameter("airline");
        String dated = request.getParameter("dated");
        String timed = request.getParameter("timed");
        String seat = request.getParameter("seat");
        String clas = request.getParameter("clas");
        
        String task = request.getParameter("task");
        String date = request.getParameter("date");
        
        
        
        String value=null;
        String name=null;
        
         Cookie ck[]=request.getCookies();  
        for(int i=0;i<ck.length;i++){  
        name= ck[i].getName();
        value = ck[i].getValue();
        }
        if(name.equals("user") || name.equals("staffmail"))
        {
            request.setAttribute("filteruser", value);
        }
          String filter = (String)request.getAttribute("filteruser");
  
        
         Reserve r1 = new Reserve();
         r1.setTitle(title);
         r1.setFname(fname);
         r1.setLname(lname);
         r1.setType(type);
         r1.setEmail(email);
         r1.setTelephone(telephone);
         r1.setId(id);
         r1.setDepartcountry(departcountry);
         r1.setDepcity(depcity);
         r1.setDescountry(descountry);
         r1.setDescity(descity);
         r1.setAirline(airline);
         r1.setDated(dated);
         r1.setTimed(timed);
         r1.setSeat(seat);
         r1.setClas(clas);
         
        r1.setPerson(filter);
        r1.setTask(task);
        r1.setDate(date);
        
        if(r1.flightCheck())
        {
            if(r1.emailCheck())
            {
            out.println("<script type=\"text/javascript\">");
            out.println("alert('This E-Mail is already used..')");
            out.println("location='viewseatlist';");
            out.println("</script>"); 
            }
         

       else if(r1.seatCheck())
        {
            out.println("<script type=\"text/javascript\">");
            out.println("alert('Seat Already Taken Please Check Reserved Seats')");
            out.println("location='viewseatlist';");
            out.println("</script>");  
        }
        else if(r1.reserveData())
        {
            out.println("<script type=\"text/javascript\">");
            out.println("alert('Reservation Added')");
            out.println("location='error.jsp';");
            out.println("</script>");  
        }
        else
        {
            out.println("<script type=\"text/javascript\">");
            out.println("alert('Reservation Failed..')");
            out.println("location='viewseatlist';");
            out.println("</script>"); 
            
       }
        }
        else
        {
            out.println("<script type=\"text/javascript\">");
            out.println("alert('Flight Details Does Not Match Check Again')");
            out.println("location='viewseatlist';");
            out.println("</script>");
        }

        
                     
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
