
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.Enumeration;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.Client;



@WebServlet(name = "clientlogin", urlPatterns = {"/clientlogin"})
public class clientlogin extends HttpServlet {


    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
    }


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        PrintWriter out = response.getWriter();
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String date = request.getParameter("date");
   
        Cookie cok = new Cookie("user",username);
        response.addCookie(cok);
        
        String ip = request.getRemoteAddr();
        

          
         Client c1 = new Client();
        c1.setUsername(username);
        c1.setPassword(password);
        c1.setPerson(username);
        c1.setIp(ip);
        c1.setDate(date);
    

        if(!c1.loginUsername() && c1.loginPassword())
        {
            out.println("<script type=\"text/javascript\">");
            out.println("alert('Invalid Username..')");
            out.println("location='clientlogin.jsp';");
            out.println("</script>");
        }
        else if(c1.loginUsername() && !c1.loginPassword())
        {
            out.println("<script type=\"text/javascript\">");
            out.println("alert('Invalid Password..')");
            out.println("location='clientlogin.jsp';");
            out.println("</script>");
        }
        else if(c1.blockedPassword())
        {
            out.println("<script type=\"text/javascript\">");
            out.println("alert('Your Account Is Blocked')");
            out.println("location='clientblock.jsp';");
            out.println("</script>");
        }
        else if(c1.login())
        {
            c1.ipmonitor();
            HttpSession s1 = request.getSession(true);
            s1.setAttribute("username", username);
            
            RequestDispatcher rd = request.getRequestDispatcher("reply");
            rd.include(request, response);
        }
        else
        {
            out.println("<script type=\"text/javascript\">");
            out.println("alert('No Account Found..Please Create An Account')");
            out.println("location='clientlogin.jsp';");
            out.println("</script>");
        }
        
        
 
              
        
        
    
}
        
    
 
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
