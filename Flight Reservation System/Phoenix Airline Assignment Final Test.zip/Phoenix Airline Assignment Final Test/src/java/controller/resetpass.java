
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Client;


@WebServlet(name = "resetpass", urlPatterns = {"/resetpass"})
public class resetpass extends HttpServlet {


    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

    }


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        PrintWriter out = response.getWriter();
        String uname = request.getParameter("uname");
        String password = request.getParameter("password");
        String task = request.getParameter("task");
        String date = request.getParameter("date");
        
        
        
        Client c1 = new Client();
        c1.setUsername(uname);
        c1.setPassword(password);
        c1.setPerson(uname);
        c1.setTask(task);
        c1.setDate(date);
        
        if(c1.blockedUsername())
        {
            out.println("<script type=\"text/javascript\">");
            out.println("alert('You Cannot Reset Password..You are blocked')");
            out.println("location='clientlogin.jsp';");
            out.println("</script>");
        }
        else if(c1.loginUsername())
        {
            if(c1.loginPassword())
            {
            out.println("<script type=\"text/javascript\">");
            out.println("alert('Please Enter a Strong Password..')");
            out.println("location='forgetpassword.jsp';");
            out.println("</script>");
            }
            else
            {
            c1.resetPassword();
            c1.track();
            out.println("<script type=\"text/javascript\">");
            out.println("alert('Password Reset Successful')");
            out.println("location='clientlogin.jsp';");
            out.println("</script>");
            }
        }
        else if(!c1.loginUsername())
        {
            out.println("<script type=\"text/javascript\">");
            out.println("alert('No Account Found')");
            out.println("location='forgetpassword.jsp';");
            out.println("</script>");
        }
        else
        {
            out.println("<script type=\"text/javascript\">");
            out.println("alert('Password Reset Unsuccessful')");
            out.println("location='forgetpassword.jsp';");
            out.println("</script>");
        }
            

       
   
            
    }


    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
