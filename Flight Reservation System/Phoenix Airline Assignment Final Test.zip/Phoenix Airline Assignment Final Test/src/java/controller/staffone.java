
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.Staff;

@WebServlet(name = "staffone", urlPatterns = {"/staffone"})
public class staffone extends HttpServlet {


    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
       
    }


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        PrintWriter out = response.getWriter();
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String type = request.getParameter("type");
        
        String date = request.getParameter("date");
        
        String ip = request.getRemoteAddr();
        

       
        Cookie s = new Cookie("staffmail",email);
        response.addCookie(s);
       
   
        Staff st = new Staff();
        st.setEmail(email);
        st.setPassword(password);
        st.setType(type);
        
        st.setPerson(email);
        st.setIp(ip);
        st.setDate(date);
          
          if(!st.loginEmail() && st.loginPassword())
          {
            out.println("<script type=\"text/javascript\">");
            out.println("alert('Invalid E-Mail..')");
            out.println("location='stafflogin.jsp';");
            out.println("</script>");
          }
          else if(st.loginEmail() && !st.loginPassword())
          {
            out.println("<script type=\"text/javascript\">");
            out.println("alert('Invalid Password..')");
            out.println("location='stafflogin.jsp';");
            out.println("</script>");
          }
          else if(st.loginTest())
          {
            out.println("<script type=\"text/javascript\">");
            out.println("alert('Account Not Approved Yet')");
            out.println("location='stafflogin.jsp';");
            out.println("</script>");
          }
        else  if(st.login())
        {
            st.staffipmonitor();
            HttpSession s1 = request.getSession(true);
            s1.setAttribute("email", email);
            if(st.getType().equals("staff1"))
                
            {
                
            HttpSession s11 = request.getSession(true);
            s11.setAttribute("type", type);
            RequestDispatcher rd = request.getRequestDispatcher("staffdashboard.jsp");
            rd.include(request, response); 
            }
            else if(st.getType().equals("staff2"))
            {
            HttpSession s12 = request.getSession(true);
            s12.setAttribute("type", type);
            RequestDispatcher rd = request.getRequestDispatcher("staffdashboardtwo.jsp");
            rd.include(request, response);
            }   
              
        }
        else
        { 
            out.println("<script type=\"text/javascript\">");
            out.println("alert('Account Not Found')");
            out.println("location='stafflogin.jsp';");
            out.println("</script>");
            
        }
            
        
        
    }

  
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
