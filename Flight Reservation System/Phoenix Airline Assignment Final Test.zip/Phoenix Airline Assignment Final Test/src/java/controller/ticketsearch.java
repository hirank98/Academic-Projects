
package controller;

import static com.sun.xml.internal.ws.api.message.Packet.Status.Response;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Ticket;


@WebServlet(name = "ticketsearch", urlPatterns = {"/ticketsearch"})
public class ticketsearch extends HttpServlet {


    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
    }


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        PrintWriter out = response.getWriter();
        String ticketid = request.getParameter("ticketid");
        String task = request.getParameter("task");
        String date = request.getParameter("date");

        String value=null;
        String name=null;
        
         Cookie ck[]=request.getCookies();  
        for(int i=0;i<ck.length;i++){  
        name= ck[i].getName();
        value = ck[i].getValue();
        }
        if(name.equals("user") || name.equals("staffmail"))
        {
            request.setAttribute("filteruser", value);
        }
          String filter = (String)request.getAttribute("filteruser");
          
        Ticket t1 = new Ticket();
        t1.setTicketid(ticketid);
        t1.setPerson(filter);
        t1.setTask(task);
        t1.setDate(date);
        
 
  
            if(t1.ticketResults().isEmpty())
            {
            out.println("<script type=\"text/javascript\">");
            out.println("alert('No Results Found');");
            out.println("location='error.jsp';");
            out.println("</script>");
}
            else
            {
                t1.track();       
               List ticketresults = t1.ticketResults();
               request.setAttribute("ticketresults", ticketresults);
               RequestDispatcher rd = request.getRequestDispatcher("ticketsearchresults.jsp");
               rd.forward(request, response);
            }
    
    }

 
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
