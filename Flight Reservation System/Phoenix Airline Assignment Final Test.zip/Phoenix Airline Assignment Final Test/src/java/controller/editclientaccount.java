
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Client;

@WebServlet(name = "editclientaccount", urlPatterns = {"/editclientaccount"})
public class editclientaccount extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

    }


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
                PrintWriter out = response.getWriter();
        String title = request.getParameter("title");
        String fname = request.getParameter("fname");
        String sname = request.getParameter("sname");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String gender = request.getParameter("gender");
        String telephone = request.getParameter("telephone");
        String eemail = request.getParameter("eemail");
        String task = request.getParameter("task");
        String date = request.getParameter("date");
 
        String value=null;
        String name=null;
        
         Cookie ck[]=request.getCookies();  
        for(int i=0;i<ck.length;i++){  
        name= ck[i].getName();
        value = ck[i].getValue();
        }
        if(name.equals("user") || name.equals("staffmail"))
        {
            request.setAttribute("filteruser", value);
        }
          String filter = (String)request.getAttribute("filteruser");
       
        
        Client c1 = new Client();
        c1.setTitle(title);
        c1.setFname(fname);
        c1.setSname(sname);
        c1.setEmail(email);
        c1.setPassword(password);
        c1.setGender(gender);
        c1.setTelephone(telephone);
        c1.setEemail(eemail);
        c1.setPerson(filter);
        c1.setTask(task);
        c1.setDate(date);
        
        
        if(c1.updateAccount())
        {
            
            c1.track();
            out.println("<script type=\"text/javascript\">");
            out.println("alert('Account Updated')");
            out.println("location='error.jsp';");
            out.println("</script>");
        }
        else
        {
            out.println("<script type=\"text/javascript\">");
            out.println("alert('Update Accout Failed..')");
            out.println("location='error.jsp';");
            out.println("</script>");
        }
            
    }

 
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
