
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Flight;

@WebServlet(name = "flight", urlPatterns = {"/flight"})
public class flight extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
       
    }


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        processRequest(request, response);
        PrintWriter out = response.getWriter();
        String id = request.getParameter("id");
        String departcountry = request.getParameter("departcountry");
        String depcity = request.getParameter("depcity");
        String descountry = request.getParameter("descountry");
        String descity = request.getParameter("descity");
        String airline = request.getParameter("airline");
        String datea = request.getParameter("datea");
        String timea = request.getParameter("timea");
        String dated = request.getParameter("dated");
        String timed = request.getParameter("timed");
        String depairport = request.getParameter("depairport");
        String desairport = request.getParameter("desairport");
        String stops = request.getParameter("stops");
        String fare = request.getParameter("fare");
        
        String task = request.getParameter("task");
        String date = request.getParameter("date");

        String value=null;
        String name=null;
        
         Cookie ck[]=request.getCookies();  
        for(int i=0;i<ck.length;i++){  
        name= ck[i].getName();
        value = ck[i].getValue();
        }
        if(name.equals("staffmail"))
        {
            request.setAttribute("filteruser", value);
        }
          String filter = (String)request.getAttribute("filteruser");
  
  
        
        
        Flight f1 = new Flight();
        f1.setId(id);
        f1.setDepartcountry(departcountry);
        f1.setDepcity(depcity);
        f1.setDescountry(descountry);
        f1.setDescity(descity);
        f1.setAirline(airline);
        f1.setDatea(datea);
        f1.setTimea(timea);
        f1.setDated(dated);
        f1.setTimed(timed);
        f1.setDepairport(depairport);
        f1.setDesairport(desairport);
        f1.setStops(stops);
        f1.setFare(fare);
        
        f1.setPerson(filter);
        f1.setTask(task);
        f1.setDate(date);
        
        if(!f1.flightCheck())
        {
        if(f1.add())
        { 
            f1.staffTrack();
            out.println("<script type=\"text/javascript\">");
            out.println("alert('Flight Data Added')");
            out.println("location='flight.jsp';");
            out.println("</script>");
        }
        else
        {
            out.println("<script type=\"text/javascript\">");
            out.println("alert('Flight Data Adding Failed!!')");
            out.println("location='flight.jsp';");
            out.println("</script>");
        }
        }
        else
        {
           out.println("<script type=\"text/javascript\">");
            out.println("alert('Flight ID Already Exists')");
            out.println("location='flight.jsp';");
            out.println("</script>");
        }
            
        
            
        
        
        
        
    }

   
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
