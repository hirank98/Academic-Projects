
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Client;

@WebServlet(name = "unblockclient", urlPatterns = {"/unblockclient"})
public class unblockclient extends HttpServlet {


    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        PrintWriter out = response.getWriter();
        String email = request.getParameter("email");
        
        String task = request.getParameter("task");
        String date = request.getParameter("date");
        
        String value=null;
        String name=null;
        
         Cookie ck[]=request.getCookies();  
        for(int i=0;i<ck.length;i++){  
        name= ck[i].getName();
        value = ck[i].getValue();
        }
        if(name.equals("staffmail"))
        {
            request.setAttribute("filteruser", value);
        }
          String filter = (String)request.getAttribute("filteruser");
          
        Client cb = new Client();
        cb.setEmail(email);
        cb.setPerson(filter);
        cb.setTask(task);
        cb.setDate(date);
        
        if(cb.unblockClient() && cb.deleteblockedClient())
        {
            cb.staffTrack();
            out.println("<script type=\"text/javascript\">");
            out.println("alert('Account Unblock Succesful..')");
            out.println("location='staffdashboard.jsp';");
            out.println("</script>");
        }
        else
        {
            out.println("<script type=\"text/javascript\">");
            out.println("alert('Account Unblock Unsuccesful..')");
            out.println("location='staffdashboard.jsp';");
            out.println("</script>");
        }      
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
