
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.AdminStaff;


@WebServlet(name = "addstaff", urlPatterns = {"/addstaff"})
public class addstaff extends HttpServlet {


    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
       
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        PrintWriter out = response.getWriter();
      
        String email = request.getParameter("email");
        
        AdminStaff ad1 =  new AdminStaff();
        ad1.setEmail(email);
        if(ad1.addStaff())
        {
            ad1.decStaff();
            out.println("<script type=\"text/javascript\">");
            out.println("alert('Approved!!!...')");
            out.println("location='adminstaffadd.jsp';");
            out.println("</script>");
        }
        else
        {
            out.println("<script type=\"text/javascript\">");
            out.println("alert('Already Approved!!!...')");
            out.println("location='adminstaffadd.jsp';");
            out.println("</script>");
        }
            
            
            
        
      
        
        
       
        
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
