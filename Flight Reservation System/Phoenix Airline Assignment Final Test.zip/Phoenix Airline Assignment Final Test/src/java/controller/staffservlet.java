
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Staff;


@WebServlet(name = "staffservlet", urlPatterns = {"/staffservlet"})
public class staffservlet extends HttpServlet {


    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
    }


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        PrintWriter out = response.getWriter();
        String fname = request.getParameter("fname");
        String sname = request.getParameter("sname");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String gender = request.getParameter("gender");
        String telephone = request.getParameter("telephone");
        String type = request.getParameter("type");
        
    
     
     Staff s1  = new Staff();
     
     s1.setFname(fname);
     s1.setSname(sname);
     s1.setEmail(email);
     s1.setPassword(password);
     s1.setGender(gender);
     s1.setTelephone(telephone);
     s1.setType(type);
     
      if(s1.testEmail())
     {
            out.println("<script type=\"text/javascript\">");
            out.println("alert('Already Created Account..')");
            out.println("location='stafflogin.jsp';");
            out.println("</script>");
     }
   else if(s1.signup())
     {
            out.println("<script type=\"text/javascript\">");
            out.println("alert('Account Send To Approval..')");
            out.println("location='stafflogin.jsp';");
            out.println("</script>");
     }
     else
     {
            out.println("<script type=\"text/javascript\">");
            out.println("alert('Account Create Failed...')");
            out.println("location='staff.jsp';");
            out.println("</script>");
     }
     
   
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
