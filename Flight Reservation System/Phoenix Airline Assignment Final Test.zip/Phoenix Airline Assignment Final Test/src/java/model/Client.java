
package model;

import static java.lang.System.out;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Client {
    
    DBcon con = new DBcon();
     
    private String email;
    private String password;
    private String fname;
    private String sname;
    private String username;
    private String title;
    private String gender;
    private String telephone;
    private String eemail;
    private String task;
    private String date;
    private String person;
    private String ip;
    
    boolean LogicState = false;
    int state=0;

 
    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }



    public String getTask() {
        return task;
    }

    public void setTask(String task) {
        this.task = task;
    }

 
    public String getDate() {
        return date;
    }


    public void setDate(String date) {
        this.date = date;
    }

    public String getPerson() {
        return person;
    }


    public void setPerson(String person) {
        this.person = person;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEemail() {
        return eemail;
    }


    public void setEemail(String eemail) {
        this.eemail = eemail;
    }
    
    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getSname() {
        return sname;
    }

    public void setSname(String sname) {
        this.sname = sname;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public String getEmail() {
        return email;
    }

    
    public void setEmail(String email) {
        this.email = email;
    }

  
    public String getPassword() {
        return password;
    }

    
    public void setPassword(String password) {
        this.password = password;
    }
   
    

    public boolean login() {
        
         try {
             PreparedStatement ps = con.Connection().prepareStatement("SELECT * FROM client WHERE username=? and password=?");
             ps.setString(1, username);
             ps.setString(2, password);
             ResultSet rs = ps.executeQuery();
             
             LogicState = rs.next();
         } catch (ClassNotFoundException | SQLException ex) {
             Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
         }
         
         return LogicState;
        
    }

    public boolean signup() {
        
       
        try {
 
                PreparedStatement pss = con.Connection().prepareStatement("INSERT INTO client VALUES(?,?,?,?,?,?,?,?)");
                pss.setString(1, title);
                pss.setString(2, fname);
                pss.setString(3, sname);
                pss.setString(4, username);
                pss.setString(5, email);
                pss.setString(6, password);
                pss.setString(7, gender);
                pss.setString(8, telephone);
                state = pss.executeUpdate();

            } catch (ClassNotFoundException | SQLException ex) {
                Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
            }
        return state == 1;
            
    }

   public List getClients()
   {
       List clientlist = new ArrayList();
       
        try {
            PreparedStatement ps = con.Connection().prepareStatement("SELECT * from client");
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
                clientlist.add(rs.getString("title"));
                clientlist.add(rs.getString("firstname"));
                clientlist.add(rs.getString("lastname"));
                clientlist.add(rs.getString("email"));
                clientlist.add(rs.getString("gender"));
                clientlist.add(rs.getString("telephone"));
                
            }
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
        }
       
       
       return clientlist;
        
    }

   public boolean updateClient()
   {
        try {
            PreparedStatement ps = con.Connection().prepareStatement("UPDATE client SET title=?,firstname=?,lastname=?,gender=?,telephone=? WHERE email=?");
           
            ps.setString(1, title);
            ps.setString(2, fname);
            ps.setString(3, sname);
            ps.setString(4, gender);
            ps.setString(5, telephone);
            ps.setString(6, email);
            
            state = ps.executeUpdate();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
        }
       
       return state == 1;
   }

    public List clientDetails()
    {
        List clientlist = new ArrayList();
        
        try {
            PreparedStatement ps = con.Connection().prepareStatement("SELECT * FROM client WHERE email LIKE '%"+email+"%'");
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
                clientlist.add(rs.getString("title"));
                clientlist.add(rs.getString("firstname"));
                clientlist.add(rs.getString("lastname"));
                clientlist.add(rs.getString("email"));
                clientlist.add(rs.getString("gender"));
                clientlist.add(rs.getString("telephone"));
                
            }
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
        }
        return clientlist;
    }

    public boolean updateAccount() {
        
        try {
            PreparedStatement ps = con.Connection().prepareStatement("UPDATE client SET title=?,firstname=?,lastname=?,email=?,password=?,gender=?,telephone=? WHERE email=?");
            ps.setString(1, title);
            ps.setString(2, fname);
            ps.setString(3, sname);
            ps.setString(4, email);
            ps.setString(5, password);
            ps.setString(6, gender);
            ps.setString(7, telephone);
            ps.setString(8, eemail);
            state = ps.executeUpdate();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
        }
       
        return state == 1;
    }

    public boolean updateClientDetails() {
        try {
            PreparedStatement ps = con.Connection().prepareStatement("UPDATE client SET title=?,firstname=?,lastname=?,gender=?,telephone=? WHERE email=?");
           
            ps.setString(1, title);
            ps.setString(2, fname);
            ps.setString(3, sname);
            ps.setString(4, gender);
            ps.setString(5, telephone);
            ps.setString(6, email);
            
            state = ps.executeUpdate();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
        }
       
       return state == 1;
    }

    public boolean change() {
        
        try {
            PreparedStatement ps = con.Connection().prepareStatement("UPDATE client SET title=?,firstname=?,lastname=?,telephone=? WHERE email=?");
            ps.setString(1, title);
            ps.setString(2, fname);
            ps.setString(3, sname);
            ps.setString(4, telephone);
            ps.setString(5, email);
            state = ps.executeUpdate();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
        }
        return state == 1;
    }

    public boolean block() {
        
        try {
            PreparedStatement ps = con.Connection().prepareStatement("INSERT into blocked SELECT * FROM client WHERE email=?");
            ps.setString(1, email);
            state = ps.executeUpdate();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
        }
        return state == 1;
    }
    
    public boolean delete()
    {
        try {
            PreparedStatement ps = con.Connection().prepareStatement("DELETE FROM client WHERE email=?");
            ps.setString(1, email);
            state = ps.executeUpdate();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
        }
        return state == 1;
    }
        


    
      public boolean track()
    {
        try {
            PreparedStatement ps = con.Connection().prepareStatement("INSERT into track(user,task,time) VALUES(?,?,?)");
            ps.setString(1, person);
            ps.setString(2, task);
            ps.setString(3, date);
            state = ps.executeUpdate();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        return state ==1;
    }
      
   public boolean staffTrack()
    {
                    try {
                        PreparedStatement ps = con.Connection().prepareStatement("INSERT into stafftracker(user,task,time) VALUES(?,?,?)");
                        ps.setString(1, person);
                        ps.setString(2, task);
                        ps.setString(3, date);
                        state = ps.executeUpdate();
                    } catch (ClassNotFoundException | SQLException ex) {
                        Logger.getLogger(Flight.class.getName()).log(Level.SEVERE, null, ex);
                    }
      
    

       return state == 1; 
    }

    public boolean ipmonitor() {
        
        try {
            PreparedStatement ps = con.Connection().prepareStatement("INSERT into ipmonitor(username,userip,logintime) VALUES(?,?,?)");
            ps.setString(1, person);
            ps.setString(2, ip);
            ps.setString(3, date);
            state = ps.executeUpdate();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
        }
        return state == 1;
    }
    
    public List getActivities()
    {
        List activity = new ArrayList();
        
        try {
            PreparedStatement ps = con.Connection().prepareStatement("SELECT * FROM track");
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
                activity.add(rs.getString("id"));
                activity.add(rs.getString("user"));
                activity.add(rs.getString("task"));
                activity.add(rs.getString("time"));
            }
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        return activity;
    }
    
    public List getSessions()
    {
        List sessionlist = new ArrayList();
        try {
            PreparedStatement ps = con.Connection().prepareStatement("SELECT * from ipmonitor");
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
                sessionlist.add(rs.getString("id"));
                sessionlist.add(rs.getString("username"));
                sessionlist.add(rs.getString("userip"));
                sessionlist.add(rs.getString("logintime"));
                
            }
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        return sessionlist;
    }
    
    public boolean loginUsername() {
        
         try {
             PreparedStatement ps = con.Connection().prepareStatement("SELECT * FROM client WHERE username=?");
             ps.setString(1, username);
             ResultSet rs = ps.executeQuery();
             
             LogicState = rs.next();
         } catch (ClassNotFoundException | SQLException ex) {
             Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
         }
         
         return LogicState;
        
    }
        public boolean loginPassword() {
        
         try {
             PreparedStatement ps = con.Connection().prepareStatement("SELECT * FROM client WHERE password=?");
             ps.setString(1, password);
             ResultSet rs = ps.executeQuery();
             
             LogicState = rs.next();
         } catch (ClassNotFoundException | SQLException ex) {
             Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
         }
         
         return LogicState;
        
    }
        
       public boolean loginEmail() {
        
         try {
             PreparedStatement ps = con.Connection().prepareStatement("SELECT * FROM client WHERE email=?");
             ps.setString(1, email);
             ResultSet rs = ps.executeQuery();
             
             LogicState = rs.next();
         } catch (ClassNotFoundException | SQLException ex) {
             Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
         }
         
         return LogicState;
        
    }
              public boolean blockedPassword() {
        
         try {
             PreparedStatement ps = con.Connection().prepareStatement("SELECT * FROM blocked WHERE username=? and password=?");
             ps.setString(1, username);
             ps.setString(2, password);
             ResultSet rs = ps.executeQuery();
             
             LogicState = rs.next();
         } catch (ClassNotFoundException | SQLException ex) {
             Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
         }
         
         return LogicState;
        
    }
   public boolean deleteClient() {
        
                try {
                    PreparedStatement ps = con.Connection().prepareStatement("DELETE from client WHERE email=?");
                    ps.setString(1, email);
                    state = ps.executeUpdate();
                } catch (ClassNotFoundException |SQLException ex) {
                    Logger.getLogger(Flight.class.getName()).log(Level.SEVERE, null, ex);
                } 
        
        
        return state == 1;
    }
   
      public boolean deleteblockedClient() {
        
                try {
                    PreparedStatement ps = con.Connection().prepareStatement("DELETE from blocked WHERE email=?");
                    ps.setString(1, email);
                    state = ps.executeUpdate();
                } catch (ClassNotFoundException |SQLException ex) {
                    Logger.getLogger(Flight.class.getName()).log(Level.SEVERE, null, ex);
                } 
        
        
        return state == 1;
    }
      
      public boolean unblockClient()
      {
        try {
            PreparedStatement ps = con.Connection().prepareStatement("INSERT INTO client SELECT * FROM blocked WHERE email=?");
            ps.setString(1, email);
            state = ps.executeUpdate();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
        }
          return state == 1;
      }
      
          public boolean blockedUsername() {
        
         try {
             PreparedStatement ps = con.Connection().prepareStatement("SELECT * FROM blocked WHERE username=?");
             ps.setString(1, username);
             ResultSet rs = ps.executeQuery();
             
             LogicState = rs.next();
         } catch (ClassNotFoundException | SQLException ex) {
             Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
         }
         
         return LogicState;
        
    }
  
          public boolean blockedEmail() {
        
         try {
             PreparedStatement ps = con.Connection().prepareStatement("SELECT * FROM blocked WHERE email=?");
             ps.setString(1, email);
             ResultSet rs = ps.executeQuery();
             
             LogicState = rs.next();
         } catch (ClassNotFoundException | SQLException ex) {
             Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
         }
         
         return LogicState;
        
    }
          public boolean resetPassword()
          {
        try {
            PreparedStatement ps = con.Connection().prepareStatement("UPDATE client SET password=? WHERE username=?");
            ps.setString(1, password);
            ps.setString(2, username);
            state = ps.executeUpdate();
            
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
        }
              return state == 1;
          }
              public boolean check() {
        
         try {
             PreparedStatement ps = con.Connection().prepareStatement("SELECT * FROM client WHERE username=? and email=?");
             ps.setString(1, person);
             ps.setString(2, email);
             ResultSet rs = ps.executeQuery();
             
             LogicState = rs.next();
         } catch (ClassNotFoundException | SQLException ex) {
             Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
         }
         
         return LogicState;
        
    } 

   
              




   

    
    
    
}
