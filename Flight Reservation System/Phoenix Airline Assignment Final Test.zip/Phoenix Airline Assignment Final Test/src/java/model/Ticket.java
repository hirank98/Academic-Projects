
package model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Ticket 
{
    private String ticketid;
    private String gate;
    private String email;
    private String task;
    private String date;
    private String person;
    private boolean LogicState;
    
    int state = 0;
    DBcon con = new DBcon();
    
     public String getTask() {
        return task;
    }

    public void setTask(String task) {
        this.task = task;
    }

 
    public String getDate() {
        return date;
    }


    public void setDate(String date) {
        this.date = date;
    }

    public String getPerson() {
        return person;
    }


    public void setPerson(String person) {
        this.person = person;
    }

  
    public String getEmail() {
        return email;
    }

 
    public void setEmail(String email) {
        this.email = email;
    }
    
 
    public String getTicketid() {
        return ticketid;
    }


    public void setTicketid(String ticketid) {
        this.ticketid = ticketid;
    }

    public String getGate() {
        return gate;
    }

    public void setGate(String gate) {
        this.gate = gate;
    }
  
        public List ticketDetails()
        {
            List ticketdetails = new ArrayList();
        try {
            
            
            PreparedStatement ps = con.Connection().prepareStatement("SELECT title, fname, lname, type, email, telephone, id, departcountry, depcity, descountry, descity, airline, dated, timed, seat, clas from reserve");
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
               ticketdetails.add(rs.getString("title"));
               ticketdetails.add(rs.getString("fname"));
               ticketdetails.add(rs.getString("lname"));
               ticketdetails.add(rs.getString("type"));
               ticketdetails.add(rs.getString("email"));
               ticketdetails.add(rs.getString("telephone"));
               ticketdetails.add(rs.getString("id"));
               ticketdetails.add(rs.getString("departcountry"));
               ticketdetails.add(rs.getString("depcity"));
               ticketdetails.add(rs.getString("descountry"));
               ticketdetails.add(rs.getString("descity"));
               ticketdetails.add(rs.getString("airline"));
               ticketdetails.add(rs.getString("dated"));
               ticketdetails.add(rs.getString("timed"));
               ticketdetails.add(rs.getString("seat"));
               ticketdetails.add(rs.getString("clas"));
            }
            
            
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Ticket.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Ticket.class.getName()).log(Level.SEVERE, null, ex);
        }
        return ticketdetails;
        }

    public boolean updateTicket() {
        
        try {
            PreparedStatement ps = con.Connection().prepareStatement("UPDATE reserve SET ticketid=?,gate=? WHERE email=?");
            ps.setString(1, ticketid);
            ps.setString(2, gate);
            ps.setString(3, email);
            state = ps.executeUpdate();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Ticket.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Ticket.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return state == 1;
        
    }
    
    public List viewTickets()
    {
        List ticketdetailss = new ArrayList();
        try {
            
            
            PreparedStatement ps = con.Connection().prepareStatement("SELECT * from reserve");
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
               ticketdetailss.add(rs.getString("ticketid"));
               ticketdetailss.add(rs.getString("gate"));
               ticketdetailss.add(rs.getString("fname"));
               ticketdetailss.add(rs.getString("lname"));
               ticketdetailss.add(rs.getString("id"));
               ticketdetailss.add(rs.getString("departcountry"));
               ticketdetailss.add(rs.getString("depcity"));
               ticketdetailss.add(rs.getString("descountry"));
               ticketdetailss.add(rs.getString("descity"));
               ticketdetailss.add(rs.getString("dated"));
               ticketdetailss.add(rs.getString("timed"));
               ticketdetailss.add(rs.getString("seat"));
               ticketdetailss.add(rs.getString("clas"));
            }
            
            
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Ticket.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Ticket.class.getName()).log(Level.SEVERE, null, ex);
        }
        return ticketdetailss;
        }
    public List ticketResults()
    {
        List searchresults = new ArrayList();
        
        try {
            PreparedStatement ps = con.Connection().prepareStatement("SELECT * FROM reserve WHERE ticketid LIKE '%"+ticketid+"%'");
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
               searchresults.add(rs.getString("ticketid"));
               searchresults.add(rs.getString("gate"));
               searchresults.add(rs.getString("fname"));
               searchresults.add(rs.getString("lname"));
               searchresults.add(rs.getString("id"));
               searchresults.add(rs.getString("departcountry"));
               searchresults.add(rs.getString("depcity"));
               searchresults.add(rs.getString("descountry"));
               searchresults.add(rs.getString("descity"));
               searchresults.add(rs.getString("dated"));
               searchresults.add(rs.getString("timed"));
               searchresults.add(rs.getString("seat"));
               searchresults.add(rs.getString("class"));
               
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Ticket.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Ticket.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return searchresults;
    }

    public boolean deleteTicket() {
        
        try {
            PreparedStatement ps = con.Connection().prepareStatement("DELETE from reserve WHERE email=?");
            ps.setString(1, email);
            state = ps.executeUpdate();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Ticket.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Ticket.class.getName()).log(Level.SEVERE, null, ex);
        }
        return state == 1;
    }
    
      public boolean track()
    {
        try {
            PreparedStatement ps = con.Connection().prepareStatement("INSERT into track(user,task,time) VALUES(?,?,?)");
            ps.setString(1, person);
            ps.setString(2, task);
            ps.setString(3, date);
            state = ps.executeUpdate();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        return state ==1;
    }
 public boolean staffTrack()
    {
                    try {
                        PreparedStatement ps = con.Connection().prepareStatement("INSERT into stafftracker(user,task,time) VALUES(?,?,?)");
                        ps.setString(1, person);
                        ps.setString(2, task);
                        ps.setString(3, date);
                        state = ps.executeUpdate();
                    } catch (ClassNotFoundException | SQLException ex) {
                        Logger.getLogger(Flight.class.getName()).log(Level.SEVERE, null, ex);
                    }
      
    

       return state == 1; 
    }
         public boolean ticketCheck() {
        
         try {
             PreparedStatement ps = con.Connection().prepareStatement("SELECT * FROM reserve WHERE ticketid=?");
             ps.setString(1, ticketid);
             ResultSet rs = ps.executeQuery();
             
             LogicState = rs.next();
         } catch (ClassNotFoundException | SQLException ex) {
             Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
         }
         
         return LogicState;
        
    }
    }



    

