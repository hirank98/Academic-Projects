
package model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Reserve {
    
   private String title;
   private String fname;
   private String lname;
   private String type;
   private String email;
   private String telephone;
   private String id;
   private String departcountry;
   private String depcity;
   private String descountry;
   private String descity;
   private String airline;
   private String dated;
   private String timed;
   private String seat;
   private String clas;
   private String eemail;
   private String task;
   private String date;
   private String person;
   
   boolean LogicState = false;
   int state = 0;
   
   DBcon con = new DBcon();


    public String getTask() {
        return task;
    }

    public void setTask(String task) {
        this.task = task;
    }

 
    public String getDate() {
        return date;
    }


    public void setDate(String date) {
        this.date = date;
    }

    public String getPerson() {
        return person;
    }


    public void setPerson(String person) {
        this.person = person;
    }
    public String getEemail() {
        return eemail;
    }

    public void setEemail(String eemail) {
        this.eemail = eemail;
    }
    


  
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
    
   
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public String getDepartcountry() {
        return departcountry;
    }

    public void setDepartcountry(String departcountry) {
        this.departcountry = departcountry;
    }

    public String getDepcity() {
        return depcity;
    }

    public void setDepcity(String depcity) {
        this.depcity = depcity;
    }

    public String getDescountry() {
        return descountry;
    }

    public void setDescountry(String descountry) {
        this.descountry = descountry;
    }

    public String getDescity() {
        return descity;
    }

    public void setDescity(String descity) {
        this.descity = descity;
    }

    public String getAirline() {
        return airline;
    }

    public void setAirline(String airline) {
        this.airline = airline;
    }

    public String getDated() {
        return dated;
    }

    public void setDated(String dated) {
        this.dated = dated;
    }

    public String getTimed() {
        return timed;
    }

    public void setTimed(String timed) {
        this.timed = timed;
    }

    public String getSeat() {
        return seat;
    }

    public void setSeat(String seat) {
        this.seat = seat;
    }

    public String getClas() {
        return clas;
    }

    public void setClas(String clas) {
        this.clas = clas;
    }

    public boolean reserveData() {
       
       try {
           PreparedStatement ps = con.Connection().prepareStatement("INSERT into reserve VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
           ps.setString(1, title);
           ps.setString(2, fname);
           ps.setString(3, lname);
           ps.setString(4, type);
           ps.setString(5, email);
           ps.setString(6, telephone);
           ps.setString(7, id);
           ps.setString(8, departcountry);
           ps.setString(9, depcity);
           ps.setString(10, descountry);
           ps.setString(11, descity);
           ps.setString(12, airline);
           ps.setString(13, dated);
           ps.setString(14, timed);
           ps.setString(15, seat);
           ps.setString(16, clas);
           ps.setString(17, "null");
           ps.setString(18, "null");

           state = ps.executeUpdate();
           
       } catch (ClassNotFoundException ex) {
           Logger.getLogger(Reserve.class.getName()).log(Level.SEVERE, null, ex);
       } catch (SQLException ex) {
           Logger.getLogger(Reserve.class.getName()).log(Level.SEVERE, null, ex);
       }
        
        return state == 1;
    }
    
    public List reservationList()
    {
        List reserveList = new ArrayList();
        
       try {
           PreparedStatement ps = con.Connection().prepareStatement("SELECT * from reserve");
           ResultSet rs = ps.executeQuery();
           while(rs.next())
           {
               reserveList.add(rs.getString("title"));
               reserveList.add(rs.getString("fname"));
               reserveList.add(rs.getString("lname"));
               reserveList.add(rs.getString("type"));
               reserveList.add(rs.getString("email"));
               reserveList.add(rs.getString("telephone"));
               reserveList.add(rs.getString("departcountry"));
               reserveList.add(rs.getString("depcity"));
               reserveList.add(rs.getString("descountry"));
               reserveList.add(rs.getString("descity"));
               reserveList.add(rs.getString("airline"));
               reserveList.add(rs.getString("dated"));
               reserveList.add(rs.getString("timed"));
               reserveList.add(rs.getString("seat"));
               reserveList.add(rs.getString("clas"));
               
           }
       } catch (ClassNotFoundException ex) {
           Logger.getLogger(Reserve.class.getName()).log(Level.SEVERE, null, ex);
       } catch (SQLException ex) {
           Logger.getLogger(Reserve.class.getName()).log(Level.SEVERE, null, ex);
       }
        
        
        return reserveList;
        
    }
    public List seatList()
    {
        List seatList = new ArrayList();
        
       try {
           PreparedStatement ps = con.Connection().prepareStatement("SELECT * from reserve WHERE id=?");
           ps.setString(1, id);
           ResultSet rs = ps.executeQuery();
           while(rs.next())
           {
               seatList.add(rs.getString("seat"));

           }
       } catch (ClassNotFoundException ex) {
           Logger.getLogger(Reserve.class.getName()).log(Level.SEVERE, null, ex);
       } catch (SQLException ex) {
           Logger.getLogger(Reserve.class.getName()).log(Level.SEVERE, null, ex);
       }
        
        
        return seatList;
        
    }

    public boolean updateTicket() {
        try {
            PreparedStatement ps = con.Connection().prepareStatement("UPDATE reserve SET title=?,fname=?,lname=?,type=?,telephone=?,id=?,departcountry=?,depcity=?,descountry=?,descity=?,airline=?,dated=?,timed=?,seat=?,clas=? WHERE email=?");
           ps.setString(1, title);
           ps.setString(2, fname);
           ps.setString(3, lname);
           ps.setString(4, type);
           ps.setString(5, telephone);
           ps.setString(6, id);
           ps.setString(7, departcountry);
           ps.setString(8, depcity);
           ps.setString(9, descountry);
           ps.setString(10, descity);
           ps.setString(11, airline);
           ps.setString(12, dated);
           ps.setString(13, timed);
           ps.setString(14, seat);
           ps.setString(15, clas);
           ps.setString(16, email);
           state = ps.executeUpdate();
            
           
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Ticket.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Ticket.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return state == 1;
    }
    
    public List reservation()
    {
        List reserveList = new ArrayList();
        
       try {
           PreparedStatement ps = con.Connection().prepareStatement("SELECT * from reserve WHERE email=?");
           ps.setString(1, email);
           ResultSet rs = ps.executeQuery();
           while(rs.next())
           {
               reserveList.add(rs.getString("title"));
               reserveList.add(rs.getString("fname"));
               reserveList.add(rs.getString("lname"));
               reserveList.add(rs.getString("type"));
               reserveList.add(rs.getString("email"));
               reserveList.add(rs.getString("telephone"));
               reserveList.add(rs.getString("id"));
               reserveList.add(rs.getString("departcountry"));
               reserveList.add(rs.getString("depcity"));
               reserveList.add(rs.getString("descountry"));
               reserveList.add(rs.getString("descity"));
               reserveList.add(rs.getString("airline"));
               reserveList.add(rs.getString("dated"));
               reserveList.add(rs.getString("timed"));
               reserveList.add(rs.getString("seat"));
               reserveList.add(rs.getString("clas"));
               
           }
       } catch (ClassNotFoundException ex) {
           Logger.getLogger(Reserve.class.getName()).log(Level.SEVERE, null, ex);
       } catch (SQLException ex) {
           Logger.getLogger(Reserve.class.getName()).log(Level.SEVERE, null, ex);
       }
        
        
        return reserveList;
        
    }

    public boolean updateReservation() {
        try {
            PreparedStatement ps = con.Connection().prepareStatement("UPDATE reserve SET title=?,fname=?,lname=?,type=?,email=?,telephone=?,departcountry=?,depcity=?,descountry=?,descity=?,dated=?,timed=?,clas=? WHERE email=?");
           ps.setString(1, title);
           ps.setString(2, fname);
           ps.setString(3, lname);
           ps.setString(4, type);
           ps.setString(5, email);
           ps.setString(6, telephone);
           ps.setString(7, departcountry);
           ps.setString(8, depcity);
           ps.setString(9, descountry);
           ps.setString(10, descity);
           ps.setString(11, dated);
           ps.setString(12, timed);
           ps.setString(13, clas);
           ps.setString(14, eemail);
           state = ps.executeUpdate();
            
           
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Ticket.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Ticket.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return state == 1;
        
    }
  public boolean track()
    {
        try {
            PreparedStatement ps = con.Connection().prepareStatement("INSERT into track(user,task,time) VALUES(?,?,?)");
            ps.setString(1, person);
            ps.setString(2, task);
            ps.setString(3, date);
            state = ps.executeUpdate();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        return state ==1;
    }
    public boolean staffTrack()
    {
                    try {
                        PreparedStatement ps = con.Connection().prepareStatement("INSERT into stafftracker(user,task,time) VALUES(?,?,?)");
                        ps.setString(1, person);
                        ps.setString(2, task);
                        ps.setString(3, date);
                        state = ps.executeUpdate();
                    } catch (ClassNotFoundException | SQLException ex) {
                        Logger.getLogger(Flight.class.getName()).log(Level.SEVERE, null, ex);
                    }
      
    

       return state == 1; 
    }
    
    public boolean seatCheck() {
        
         try {
             PreparedStatement ps = con.Connection().prepareStatement("SELECT * FROM reserve WHERE seat=? and id=?");
             ps.setString(1, seat);
             ps.setString(2, id);
             ResultSet rs = ps.executeQuery();
             
             LogicState = rs.next();
         } catch (ClassNotFoundException | SQLException ex) {
             Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
         }
         
         return LogicState;
        
    }
    
    public boolean flightCheck() {
        
         try {
             PreparedStatement ps = con.Connection().prepareStatement("SELECT * FROM flight WHERE id=? and departcountry=? and depcity=? and descountry=? and descity=? and airline=? and dated=? and timed=?");
             ps.setString(1, id);
             ps.setString(2, departcountry);
             ps.setString(3, depcity);
             ps.setString(4, descountry);
             ps.setString(5, descity);
             ps.setString(6, airline);
             ps.setString(7, dated);
             ps.setString(8, timed);
             
             ResultSet rs = ps.executeQuery();
             
             LogicState = rs.next();
         } catch (ClassNotFoundException | SQLException ex) {
             Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
         }
         
         return LogicState;
        
    }
        public boolean emailCheck() {
        
         try {
             PreparedStatement ps = con.Connection().prepareStatement("SELECT * FROM reserve WHERE email=?");
             ps.setString(1, email);
             ResultSet rs = ps.executeQuery();
             
             LogicState = rs.next();
         } catch (ClassNotFoundException | SQLException ex) {
             Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
         }
         
         return LogicState;
        
    }
    
    
    
   
    
}
