
package model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Flight {
    
                private    String id;
            private    String departcountry ;
            private    String depcity ;
            private    String descountry; 
            private    String descity ;
            private    String airline ;
            private    String datea ;
            private    String timea ;
            private    String dated ;
            private    String timed;
            private    String depairport; 
            private    String desairport ;
            private    String stops;
            private    String fare;
            private    String task;
            private    String date;
            private    String person;
            int state =0;
            boolean LogicState;
            
            DBcon con = new DBcon();

 
    public String getTask() {
        return task;
    }

    public void setTask(String task) {
        this.task = task;
    }

 
    public String getDate() {
        return date;
    }


    public void setDate(String date) {
        this.date = date;
    }

    public String getPerson() {
        return person;
    }


    public void setPerson(String person) {
        this.person = person;
    }

    public String getId() {
        return id;
    }

   
    public void setId(String id) {
        this.id = id;
    }

  
    public String getDepartcountry() {
        return departcountry;
    }

   
    public void setDepartcountry(String departcountry) {
        this.departcountry = departcountry;
    }

    public String getDepcity() {
        return depcity;
    }

    public void setDepcity(String depcity) {
        this.depcity = depcity;
    }

    public String getDescountry() {
        return descountry;
    }

    public void setDescountry(String descountry) {
        this.descountry = descountry;
    }

    public String getDescity() {
        return descity;
    }

    public void setDescity(String descity) {
        this.descity = descity;
    }

    public String getAirline() {
        return airline;
    }


    public void setAirline(String airline) {
        this.airline = airline;
    }

    public String getDatea() {
        return datea;
    }

    public void setDatea(String datea) {
        this.datea = datea;
    }

    public String getTimea() {
        return timea;
    }


    public void setTimea(String timea) {
        this.timea = timea;
    }

    public String getDated() {
        return dated;
    }

    public void setDated(String dated) {
        this.dated = dated;
    }

    public String getTimed() {
        return timed;
    }


    public void setTimed(String timed) {
        this.timed = timed;
    }

    public String getDepairport() {
        return depairport;
    }


    public void setDepairport(String depairport) {
        this.depairport = depairport;
    }

    public String getDesairport() {
        return desairport;
    }

    public void setDesairport(String desairport) {
        this.desairport = desairport;
    }

    public String getStops() {
        return stops;
    }

    public void setStops(String stops) {
        this.stops = stops;
    }

    public String getFare() {
        return fare;
    }

    public void setFare(String fare) {
        this.fare = fare;
    }

    public boolean add() {
        
        
                try {
                    PreparedStatement ps = con.Connection().prepareStatement("INSERT into flight VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
                    ps.setString(1, id);
                    ps.setString(2, departcountry);
                    ps.setString(3, depcity);
                    ps.setString(4, descountry);
                    ps.setString(5, descity);
                    ps.setString(6, airline);
                    ps.setString(7, datea);
                    ps.setString(8, timea);
                    ps.setString(9, dated);
                    ps.setString(10, timed);
                    ps.setString(11, depairport);
                    ps.setString(12, desairport);
                    ps.setString(13, stops);
                    ps.setString(14, fare);
                    
                    state = ps.executeUpdate();
                    
                    
                    
                
                } catch (ClassNotFoundException | SQLException ex) {
                    Logger.getLogger(Flight.class.getName()).log(Level.SEVERE, null, ex);
                }
        
        return state == 1;
    }
    
    public List getFlights()
    {
        List flightlist = new ArrayList();
                try {
                    PreparedStatement ps = con.Connection().prepareStatement("SELECT * from flight");
                    ResultSet rs = ps.executeQuery();
                    while(rs.next())
                    {
                        flightlist.add(rs.getString("id"));
                        flightlist.add(rs.getString("departcountry"));
                        flightlist.add(rs.getString("depcity"));
                        flightlist.add(rs.getString("descountry"));
                        flightlist.add(rs.getString("descity"));
                        flightlist.add(rs.getString("airline"));
                        flightlist.add(rs.getString("datea"));
                        flightlist.add(rs.getString("timea"));
                        flightlist.add(rs.getString("dated"));
                        flightlist.add(rs.getString("timed"));
                        flightlist.add(rs.getString("depairport"));
                        flightlist.add(rs.getString("desairport"));
                        flightlist.add(rs.getString("stops"));
                        flightlist.add(rs.getString("fare"));
                        
                    }
                } catch (ClassNotFoundException | SQLException ex) {
                    Logger.getLogger(Flight.class.getName()).log(Level.SEVERE, null, ex);
                }
        
        return flightlist;
        
    }

    public boolean updateFlight() {
        
                try {
                    PreparedStatement ps = con.Connection().prepareStatement("UPDATE flight SET descountry=?,descity=?,airline=?,datea=?,timea=?,dated=?,timed=?,depairport=?,desairport=?,stops=?,fare=? WHERE id=?");
                    
                    
                    ps.setString(1, descountry);
                    ps.setString(2, descity);
                    ps.setString(3, airline);
                    ps.setString(4, datea);
                    ps.setString(5, timea);
                    ps.setString(6, dated);
                    ps.setString(7, timed);
                    ps.setString(8, depairport);
                    ps.setString(9, desairport);
                    ps.setString(10, stops);
                    ps.setString(11, fare);
                    ps.setString(12, id);
                    
                    state = ps.executeUpdate();
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(Flight.class.getName()).log(Level.SEVERE, null, ex);
                } catch (SQLException ex) {
                    Logger.getLogger(Flight.class.getName()).log(Level.SEVERE, null, ex);
                }
                
                return state == 1;
    }

    public boolean deleteFlight() {
        
                try {
                    PreparedStatement ps = con.Connection().prepareStatement("DELETE from flight WHERE id=?");
                    ps.setString(1, id);
                    state = ps.executeUpdate();
                } catch (ClassNotFoundException |SQLException ex) {
                    Logger.getLogger(Flight.class.getName()).log(Level.SEVERE, null, ex);
                } 
        
        
        return state == 1;
    }

    public  List filterFlights() {
        
        List flightlist = new ArrayList();
                try {
                    PreparedStatement ps = con.Connection().prepareStatement("SELECT * FROM flight WHERE descountry LIKE '%"+descountry+"%' AND dated LIKE '%"+dated+"%'");
                    ResultSet rs = ps.executeQuery();
                    while(rs.next())
                    {
                        flightlist.add(rs.getString("id"));
                        flightlist.add(rs.getString("departcountry"));
                        flightlist.add(rs.getString("depcity"));
                        flightlist.add(rs.getString("descountry"));
                        flightlist.add(rs.getString("descity"));
                        flightlist.add(rs.getString("airline"));
                        flightlist.add(rs.getString("datea"));
                        flightlist.add(rs.getString("timea"));
                        flightlist.add(rs.getString("dated"));
                        flightlist.add(rs.getString("timed"));
                        flightlist.add(rs.getString("depairport"));
                        flightlist.add(rs.getString("desairport"));
                        flightlist.add(rs.getString("stops"));
                        flightlist.add(rs.getString("fare"));
                        
                    }
                } catch (ClassNotFoundException | SQLException ex) {
                    Logger.getLogger(Flight.class.getName()).log(Level.SEVERE, null, ex);
                }
        
        return flightlist;
        
    }

    public List searchFlight() {
        
        List flightlist = new ArrayList();
        
        
        
                try {
                    PreparedStatement ps = con.Connection().prepareStatement("SELECT * FROM flight WHERE id LIKE '%"+id+"%'");
                    ResultSet rs = ps.executeQuery();
                    while(rs.next())
                    {
                        flightlist.add(rs.getString("id"));
                        flightlist.add(rs.getString("departcountry"));
                        flightlist.add(rs.getString("depcity"));
                        flightlist.add(rs.getString("descountry"));
                        flightlist.add(rs.getString("descity"));
                        flightlist.add(rs.getString("airline"));
                        flightlist.add(rs.getString("datea"));
                        flightlist.add(rs.getString("timea"));
                        flightlist.add(rs.getString("dated"));
                        flightlist.add(rs.getString("timed"));
                        flightlist.add(rs.getString("depairport"));
                        flightlist.add(rs.getString("desairport"));
                        flightlist.add(rs.getString("stops"));
                        flightlist.add(rs.getString("fare"));
                        
                    }
                } catch (ClassNotFoundException | SQLException ex) {
                    Logger.getLogger(Flight.class.getName()).log(Level.SEVERE, null, ex);
                }
        
        
        return flightlist;
        
    }
    
      public boolean track()
    {
        try {
            PreparedStatement ps = con.Connection().prepareStatement("INSERT into track(user,task,time) VALUES(?,?,?)");
            ps.setString(1, person);
            ps.setString(2, task);
            ps.setString(3, date);
            state = ps.executeUpdate();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        return state ==1;
    }
        
public boolean staffTrack()
    {
                    try {
                        PreparedStatement ps = con.Connection().prepareStatement("INSERT into stafftracker(user,task,time) VALUES(?,?,?)");
                        ps.setString(1, person);
                        ps.setString(2, task);
                        ps.setString(3, date);
                        state = ps.executeUpdate();
                    } catch (ClassNotFoundException | SQLException ex) {
                        Logger.getLogger(Flight.class.getName()).log(Level.SEVERE, null, ex);
                    }
      
    

       return state == 1; 
    }
       public boolean flightCheck() {
        
         try {
             PreparedStatement ps = con.Connection().prepareStatement("SELECT * FROM flight WHERE id=?");
             ps.setString(1, id);
             ResultSet rs = ps.executeQuery();
             
             LogicState = rs.next();
         } catch (ClassNotFoundException | SQLException ex) {
             Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
         }
         
         return LogicState;
        
    }
}
            
    

