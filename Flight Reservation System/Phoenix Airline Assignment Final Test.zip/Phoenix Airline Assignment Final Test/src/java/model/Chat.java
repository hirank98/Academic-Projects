
package model;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Chat {
    
    private String cchat;
    private String schat;
    private String email;
    private String task;
    private String date;
    private String person;
   
     boolean LogicState = false;
    
    
    int state= 0;
    
    DBcon con = new DBcon();

        
      public String getTask() {
        return task;
    }

    public void setTask(String task) {
        this.task = task;
    }

 
    public String getDate() {
        return date;
    }


    public void setDate(String date) {
        this.date = date;
    }

    public String getPerson() {
        return person;
    }


    public void setPerson(String person) {
        this.person = person;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    
 
    public String getCchat() {
        return cchat;
    }

    public void setCchat(String cchat) {
        this.cchat = cchat;
    }

    public String getSchat() {
        return schat;
    }

    public void setSchat(String schat) {
        this.schat = schat;
    }
    
    

    public boolean chat() {
        
        try {
            PreparedStatement ps = con.Connection().prepareStatement("INSERT into chat(email,cchat) VALUES(?,?)");
            ps.setString(1,email);
            ps.setString(2, cchat);
            state = ps.executeUpdate();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Chat.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Chat.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        return state == 1;
        
    }
    
    public List chatList()
    {
        List chatlist  = new ArrayList();
        
        try {
            PreparedStatement ps = con.Connection().prepareStatement("SELECT * from chat");
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
            chatlist.add(rs.getString("id"));
            chatlist.add(rs.getString("email"));
            chatlist.add(rs.getString("cchat"));
            
            }
            
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Chat.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        return chatlist;
        
    }

    public boolean deleteChat() {
        
        
            PreparedStatement ps;
        try {
            ps = con.Connection().prepareStatement("DELETE FROM schat WHERE email=?");
            ps.setString(1, email);
            state = ps.executeUpdate();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Chat.class.getName()).log(Level.SEVERE, null, ex);
        }
            
            
        
        return state == 1;
        
    }

    public boolean schat() {
       try {
            PreparedStatement ps = con.Connection().prepareStatement("INSERT into schat VALUES(?,?)");
            ps.setString(1,email);
            ps.setString(2, schat);
            state = ps.executeUpdate();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Chat.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        return state == 1;
    }
    
    public List getChat()
    {
        List chats = new ArrayList();
        
        try {
            PreparedStatement ps = con.Connection().prepareStatement("SELECT * FROM schat WHERE email LIKE '"+email+"'");
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
            chats.add(rs.getString("schat"));            
            }
            
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Chat.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return chats;
        
        
    }
    
    public boolean backChat()
    { 
       try {
            PreparedStatement ps = con.Connection().prepareStatement("INSERT into chatback SELECT * FROM chat WHERE email=?");
            ps.setString(1, email);
            state = ps.executeUpdate();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Chat.class.getName()).log(Level.SEVERE, null, ex);
        }

        try {
            PreparedStatement ps = con.Connection().prepareStatement("DELETE FROM chat WHERE email=?");
            ps.setString(1, email);
            state = ps.executeUpdate();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Chat.class.getName()).log(Level.SEVERE, null, ex);
        }

        
        
        return state == 1;
    }
          public boolean track()
    {
        try {
            PreparedStatement ps = con.Connection().prepareStatement("INSERT into track(user,task,time) VALUES(?,?,?)");
            ps.setString(1, person);
            ps.setString(2, task);
            ps.setString(3, date);
            state = ps.executeUpdate();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        return state ==1;
    }
          public boolean staffTrack()
    {
                    try {
                        PreparedStatement ps = con.Connection().prepareStatement("INSERT into stafftracker(user,task,time) VALUES(?,?,?)");
                        ps.setString(1, person);
                        ps.setString(2, task);
                        ps.setString(3, date);
                        state = ps.executeUpdate();
                    } catch (ClassNotFoundException | SQLException ex) {
                        Logger.getLogger(Flight.class.getName()).log(Level.SEVERE, null, ex);
                    }
      
    

       return state == 1; 
    }
    
              public boolean check() {
        
         try {
             PreparedStatement ps = con.Connection().prepareStatement("SELECT * FROM client WHERE username=? and email=?");
             ps.setString(1, person);
             ps.setString(2, email);
             ResultSet rs = ps.executeQuery();
             
             LogicState = rs.next();
         } catch (ClassNotFoundException | SQLException ex) {
             Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
         }
         
         return LogicState;
        
    }  
 

}
