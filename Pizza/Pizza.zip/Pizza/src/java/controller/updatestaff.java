/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Admin;
import model.Staff;

@WebServlet(name = "updatestaff", urlPatterns = {"/updatestaff"})
public class updatestaff extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        
        PrintWriter out = response.getWriter();
        String fname = request.getParameter("fname");
        String sname = request.getParameter("sname");
        String id = request.getParameter("id");
        String password = request.getParameter("spassword");
        String dob = request.getParameter("dob");
        String gender = request.getParameter("gender");
        String nic = request.getParameter("nic");
        String telephone = request.getParameter("telephone");
        String type = request.getParameter("type");
        
        //out.print(""+fname+""+sname+""+id+""+password+""+dob+""+gender+""+nic+""+telephone+""+type);
      Admin as = new Admin();
        
        as.setFname(fname);
        as.setSname(sname);
        as.setPassword(password);
        as.setDob(dob);
        as.setGender(gender);
        as.setNic(nic);
        as.setTelephone(telephone);
        as.setType(type);
        as.setUid(id);
        
                if(as.updateStaff())
        {
            out.println("<script type=\"text/javascript\">");
            out.println("alert(' Staff Deatils Updated..')");
            out.println("location='editstaff.jsp';");
            out.println("</script>");
                    
        }
            
        else
        {
            out.println("<script type=\"text/javascript\">");
            out.println("alert(' Staff Deatils Update Failed..')");
            out.println("location='editstaff.jsp';");
            out.println("</script>");
        }

        
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
