/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.Order;


@WebServlet(name = "order", urlPatterns = {"/order"})
public class order extends HttpServlet {


    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
      

    }


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
 
        
    }


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       // processRequest(request, response);
        
        PrintWriter out = response.getWriter();
        String fname = request.getParameter("fname");
        String sname = request.getParameter("sname");
        String addr = request.getParameter("addr");
        String telephone = request.getParameter("telephone");
        String type = request.getParameter("type");
        String size = request.getParameter("size");
        int quantity =Integer.parseInt(request.getParameter("quantity"));
        String date = request.getParameter("date");
        int price = 0;
        
        if(size.equals("small"))
        {
            price = 750 * quantity;
        }
        else if(size.equals("large"))
        {
            price = 1250 * quantity;
        }   
        String q = String.valueOf(quantity);
        String payment = String.valueOf(price);
        
   //     out.println(""+fname+""+sname+""+telephone+""+type+""+size+""+quantity+""+price+""+q+""+payment);
       Order o = new Order();
        o.setFname(fname);
        o.setSname(sname);
        o.setAddress(addr);
        o.setTelephone(telephone);
        o.setType(type);
        o.setSize(size);
        o.setQuantity(q);
        o.setPrice(payment);
        o.setOrderdate(date);
        
         if(o.placeorder())
         {
            request.setAttribute("fname", fname); 
            request.setAttribute("sname", sname); 
            request.setAttribute("date", date); 
            request.setAttribute("type", type); 
            request.setAttribute("payment", payment);  
            request.getRequestDispatcher("payment.jsp").forward(request, response);
          /* out.println("<script type=\"text/javascript\">");
            out.println("alert('Staff Added..')");
            out.println("location='admindashboard.jsp';");
            out.println("</script>");  */
         }

       
            
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
