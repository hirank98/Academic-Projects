
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Staff;


@WebServlet(name = "filterstaff", urlPatterns = {"/filterstaff"})
public class filterstaff extends HttpServlet {


    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

    }


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
         PrintWriter out = response.getWriter();
        String id = request.getParameter("id");
 
     Staff s1 = new Staff();
        s1.setId(id);
        if(s1.staffResults().isEmpty())
            {
            out.println("<script type=\"text/javascript\">");
            out.println("alert('No Results Found');");
            out.println("location='viewtrack.jsp';");
            out.println("</script>");
}
            else
            {   
               List staffresults = s1.staffResults();
               request.setAttribute("staffresults", staffresults);
               RequestDispatcher rd = request.getRequestDispatcher("staffresults.jsp");
               rd.forward(request, response);
            }
    
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
