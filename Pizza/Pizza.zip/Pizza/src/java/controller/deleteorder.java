/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Order;

@WebServlet(name = "deleteorder", urlPatterns = {"/deleteorder"})
public class deleteorder extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        PrintWriter out = response.getWriter();
        
        String id = request.getParameter(("id"));
        
        Order o = new Order();
        o.setOrderid(id);
        
        if(o.deleteOrder())
        {
            out.println("<script type=\"text/javascript\">");
            out.println("alert(' Order Deleted..')");
            out.println("location='vieworder.jsp';");
            out.println("</script>");      
        }
        else
        {
            out.println("<script type=\"text/javascript\">");
            out.println("alert(' Order Delete Failed..')");
            out.println("location='vieworder.jsp';");
            out.println("</script>");    
        }
        
    }


    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
