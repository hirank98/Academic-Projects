
package model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Staff {
    
    DBcon con = new DBcon();
    
    private String email;
    private String password;
    private String type;
    private String fname;
    private String sname;
    private String gender;
    private String telephone;
    private String date;
    private String id;
    
    int state = 0 ;
    boolean LogicState = false;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }


    public String getDate() {
        return date;
    }


    public void setDate(String date) {
        this.date = date;
    }

    
    public String getFname() {
        return fname;
    }

    
    public void setFname(String fname) {
        this.fname = fname;
    }

    
    public String getSname() {
        return sname;
    }

    
    public void setSname(String sname) {
        this.sname = sname;
    }

    
    public String getGender() {
        return gender;
    }

    
    public void setGender(String gender) {
        this.gender = gender;
    }

    
    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }
    
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getType() {
        return type;
    }
    
    public void setType(String type) {
        this.type = type;
    }
    
    
       public boolean loginId() {
        
         try {
             PreparedStatement ps = con.Connection().prepareStatement("SELECT * FROM staff WHERE staffid=?");
             ps.setString(1, id);
             ResultSet rs = ps.executeQuery();
             
             LogicState = rs.next();
         } catch (ClassNotFoundException | SQLException ex) {
             Logger.getLogger(Staff.class.getName()).log(Level.SEVERE, null, ex);
         }
         
         return LogicState;
        
    }
              public boolean loginPassword() {
        
         try {
             PreparedStatement ps = con.Connection().prepareStatement("SELECT * FROM staff WHERE password=?");
             ps.setString(1, password);
             ResultSet rs = ps.executeQuery();
             
             LogicState = rs.next();
         } catch (ClassNotFoundException | SQLException ex) {
             Logger.getLogger(Staff.class.getName()).log(Level.SEVERE, null, ex);
         }
         
         return LogicState;
        
    }
              
    public boolean login() {
       
        try {
            PreparedStatement ps = con.Connection().prepareStatement("SELECT * FROM staff WHERE staffid=? and password=?");
            
            ps.setString(1, id);
            ps.setString(2, password);
           
            ResultSet rs = ps.executeQuery();
            LogicState = rs.next();
            
            ;
        } catch (ClassNotFoundException | SQLException  ex) {
            Logger.getLogger(Staff.class.getName()).log(Level.SEVERE, null, ex);
        } 
                
    return LogicState;
    }
      public boolean staffmonitor() {
        
        try {
            PreparedStatement ps = con.Connection().prepareStatement("INSERT into staffmonitor(staffid,logintime) VALUES(?,?)");
            ps.setString(1, id);
            ps.setString(2, date);
            state = ps.executeUpdate();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Staff.class.getName()).log(Level.SEVERE, null, ex);
        }
        return state == 1;
    }
                  
     public List getClients()
   {
       List clientlist = new ArrayList();
       
        try {
            PreparedStatement ps = con.Connection().prepareStatement("SELECT * from staff");
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
                clientlist.add(rs.getString("staffid"));
                clientlist.add(rs.getString("fname"));
                clientlist.add(rs.getString("sname"));
                clientlist.add(rs.getString("email"));
                clientlist.add(rs.getString("password"));
                clientlist.add(rs.getString("dob"));
                clientlist.add(rs.getString("gender"));
                clientlist.add(rs.getString("nic"));
                clientlist.add(rs.getString("telephone"));
                clientlist.add(rs.getString("type"));
                
            }
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Staff.class.getName()).log(Level.SEVERE, null, ex);
        }
       
       
       return clientlist;
        
    }
         public List  staffResults()
    {
        List searchresults = new ArrayList();
        
        try {
            PreparedStatement ps = con.Connection().prepareStatement("SELECT * FROM staff WHERE staffid LIKE '%"+id+"%'");
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
               searchresults.add(rs.getString("staffid"));
               searchresults.add(rs.getString("fname"));
               searchresults.add(rs.getString("sname"));
               searchresults.add(rs.getString("email"));
               searchresults.add(rs.getString("dob"));
               searchresults.add(rs.getString("gender"));
               searchresults.add(rs.getString("nic"));
               searchresults.add(rs.getString("telephone"));
               searchresults.add(rs.getString("type"));
               
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Staff.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Staff.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return searchresults;
    }
     
 
     

}