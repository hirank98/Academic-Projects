/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author Chalaka
 */
public class Admin {



    
    private String uid;
    private String password;
    private String fname;
    private String sname;
    private String email;
    private String dob;
    private String gender;
    private String nic;
    private String telephone;
    private String type;
    int state =0;
    boolean LogicState = false;
    
        /**
     * @return the uid
     */
    public String getUid() {
        return uid;
    }

    /**
     * @param uid the uid to set
     */
    public void setUid(String uid) {
        this.uid = uid;
    }

    /**
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param password the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * @return the fname
     */
    public String getFname() {
        return fname;
    }

    /**
     * @param fname the fname to set
     */
    public void setFname(String fname) {
        this.fname = fname;
    }

    /**
     * @return the sname
     */
    public String getSname() {
        return sname;
    }

    /**
     * @param sname the sname to set
     */
    public void setSname(String sname) {
        this.sname = sname;
    }

    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return the spassword
     */

    /**
     * @return the gender
     */
    public String getGender() {
        return gender;
    }

    /**
     * @param gender the gender to set
     */
    public void setGender(String gender) {
        this.gender = gender;
    }

    /**
     * @return the telephone
     */
    public String getTelephone() {
        return telephone;
    }

    /**
     * @param telephone the telephone to set
     */
    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    /**
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }
    
        /**
     * @return the nic
     */
    public String getNic() {
        return nic;
    }

    /**
     * @param nic the nic to set
     */
    public void setNic(String nic) {
        this.nic = nic;
    }

    /**
     * @return the dob
     */
    public String getDob() {
        return dob;
    }

    /**
     * @param dob the dob to set
     */
    public void setDob(String dob) {
        this.dob = dob;
    }

   
    DBcon con = new DBcon();

    public boolean login() {
        
         try {
             PreparedStatement ps = con.Connection().prepareStatement("SELECT * FROM admin WHERE userid=? and password=?");
             ps.setString(1, uid);
             ps.setString(2, password);
             ResultSet rs = ps.executeQuery();
             
             LogicState = rs.next();
         } catch (ClassNotFoundException | SQLException ex) {
             Logger.getLogger(Admin.class.getName()).log(Level.SEVERE, null, ex);
         }
         
         return LogicState;
        
    }
        public boolean addstaff()
    {
        try {
            PreparedStatement ps = con.Connection().prepareStatement("INSERT INTO staff(fname,sname,email,password,dob,gender,nic,telephone,type) VALUES(?,?,?,?,?,?,?,?,?)");
            ps.setString(1, fname);
            ps.setString(2, sname);
            ps.setString(3, email);
            ps.setString(4, password);
            ps.setString(5, dob);
            ps.setString(6, gender);
            ps.setString(7, nic);
            ps.setString(8, telephone);
            ps.setString(9, type);
            state = ps.executeUpdate();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Admin.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Admin.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return state  == 1;
    }
           public boolean updateStaff() {
        
                try {
                    PreparedStatement ps = con.Connection().prepareStatement("UPDATE staff SET fname=?,sname=?,password=?,dob=?,gender=?,nic=?,telephone=?,type=? WHERE staffid=?");
                    
                    
            ps.setString(1, fname);
            ps.setString(2, sname);
            ps.setString(3, password);
            ps.setString(4, dob);
            ps.setString(5, gender);
            ps.setString(6, nic);
            ps.setString(7, telephone);
            ps.setString(8, type);
            ps.setString(9, uid);
            
                    
                    state = ps.executeUpdate();
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(Admin.class.getName()).log(Level.SEVERE, null, ex);
                } catch (SQLException ex) {
                    Logger.getLogger(Admin.class.getName()).log(Level.SEVERE, null, ex);
                }
                
                return state == 1;
    } 
        
        public boolean deleteStaff() {
        
                try {
                    PreparedStatement ps = con.Connection().prepareStatement("DELETE from staff WHERE email=?");
                    ps.setString(1, email);
                    state = ps.executeUpdate();
                } catch (ClassNotFoundException |SQLException ex) {
                    Logger.getLogger(Staff.class.getName()).log(Level.SEVERE, null, ex);
                } 
        
        
        return state == 1;
    }
    
}
