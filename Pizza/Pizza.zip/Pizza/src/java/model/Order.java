/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author Chalaka
 */
public class Order {

    private String fname;
    private String sname;
    private String address;
    private String telephone;
    private String type;
    private String size;
    private String quantity;
    private String price;
    private String orderid;
    private String orderdate;
    int state =0;
    boolean LogicState = false;
    
    DBcon con = new DBcon();
    
    
        /**
     * @return the orderdate
     */
    public String getOrderdate() {
        return orderdate;
    }

    /**
     * @param orderdate the orderdate to set
     */
    public void setOrderdate(String orderdate) {
        this.orderdate = orderdate;
    }
        /**
     * @return the orderid
     */
    public String getOrderid() {
        return orderid;
    }

    /**
     * @param orderid the orderid to set
     */
    public void setOrderid(String orderid) {
        this.orderid = orderid;
    }

 
    public String getAddress() {
        return address;
    }


    public void setAddress(String address) {
        this.address = address;
    }
    public String getQuantity() {
        return quantity;
    }

    /**
     * @param quantity the quantity to set
     */
    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    /**
     * @return the price
     */
    public String getPrice() {
        return price;
    }

    /**
     * @param price the price to set
     */
    public void setPrice(String price) {
        this.price = price;
    }


    /**
     * @return the fname
     */
    public String getFname() {
        return fname;
    }

    /**
     * @param fname the fname to set
     */
    public void setFname(String fname) {
        this.fname = fname;
    }

    /**
     * @return the sname
     */
    public String getSname() {
        return sname;
    }

    /**
     * @param sname the sname to set
     */
    public void setSname(String sname) {
        this.sname = sname;
    }

    /**
     * @return the telephone
     */
    public String getTelephone() {
        return telephone;
    }

    /**
     * @param telephone the telephone to set
     */
    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    /**
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * @return the size
     */
    public String getSize() {
        return size;
    }

    /**
     * @param size the size to set
     */
    public void setSize(String size) {
        this.size = size;
    }

    /**
     * @return the quantity
     */
        public boolean placeorder()
    {
        try {
            PreparedStatement ps = con.Connection().prepareStatement("INSERT INTO orders(firstname,lastname,address,telephone,type,size,quantity,price,orderdate) VALUES(?,?,?,?,?,?,?,?,?)");
            ps.setString(1, fname);
            ps.setString(2, sname);
            ps.setString(3, address);
            ps.setString(4, telephone);
            ps.setString(5, type);
            ps.setString(6, size);
            ps.setString(7, quantity);
            ps.setString(8, price);
            ps.setString(9, orderdate);
            state = ps.executeUpdate();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Admin.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Admin.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return state  == 1;
    }
          public boolean updateOrder()
   {
        try {
            PreparedStatement ps = con.Connection().prepareStatement("UPDATE orders SET firstname=?,lastname=?,address=?,telephone=?,type=?,size=?,quantity=?,price=? WHERE orderid=?");
           
            ps.setString(1, fname);
            ps.setString(2, sname);
            ps.setString(3, address);
            ps.setString(4, telephone);
            ps.setString(5, type);
            ps.setString(6, size);
            ps.setString(7, quantity);
            ps.setString(8, price);
            ps.setString(9, orderid);
            
            state = ps.executeUpdate();

        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Staff.class.getName()).log(Level.SEVERE, null, ex);
        }
       
       return state == 1;
   }  
          
            
        public boolean deleteOrder() {
        
                try {
                    PreparedStatement ps = con.Connection().prepareStatement("DELETE from orders WHERE orderid=?");
                    ps.setString(1, orderid);
                    state = ps.executeUpdate();
                } catch (ClassNotFoundException |SQLException ex) {
                    Logger.getLogger(Staff.class.getName()).log(Level.SEVERE, null, ex);
                } 
        
        
        return state == 1;
    }
        
    public  List filterOrders() {
        
        List orderlist = new ArrayList();
                try {
                    PreparedStatement ps = con.Connection().prepareStatement("SELECT * FROM orders WHERE telephone LIKE '%"+telephone+"%'");
                    ResultSet rs = ps.executeQuery();
                    while(rs.next())
                    {
                         orderlist.add(rs.getString("orderid"));
                         orderlist.add(rs.getString("firstname"));
                         orderlist.add(rs.getString("lastname"));
                         orderlist.add(rs.getString("address"));
                         orderlist.add(rs.getString("telephone"));
                         orderlist.add(rs.getString("type"));
                         orderlist.add(rs.getString("size"));
                         orderlist.add(rs.getString("quantity"));
                         orderlist.add(rs.getString("price"));
                         orderlist.add(rs.getString("orderdate"));
                         
                    }
                } catch (ClassNotFoundException | SQLException ex) {
                    Logger.getLogger(Order.class.getName()).log(Level.SEVERE, null, ex);
                }
        
        return orderlist;
        
    }
        
    
        
    
    

}
